﻿using Microsoft.EntityFrameworkCore;

namespace SmartBin.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<SuccessStory> SuccessStories { get; set; }

        public DbSet<Bin> Bins { get; set; }

        public DbSet<Report> Reports { get; set; }

    }
}
