﻿using System.ComponentModel.DataAnnotations;

namespace SmartBin.Models
{
    public class Report
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string HouseNumber { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public int BinId { get; set; }

        [Required]
        public string BinStatus { get; set; } // Options: "Filled", "Empty", "Partial"

        [Required]
        public string CollectBinUpdate { get; set; } // Options: "Collected" or "Not Collected"

        [Required]
        public string ContaminationAlert { get; set; } // Options: "Good", "Bad", "Normal"
    }
}
