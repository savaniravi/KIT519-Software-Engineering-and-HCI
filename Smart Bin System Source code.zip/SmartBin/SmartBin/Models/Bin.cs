﻿using System.ComponentModel.DataAnnotations;

namespace SmartBin.Models
{
    public class Bin
    {
        [Key]
        public int BinId { get; set; }

        [Required]
        public string FillStatus { get; set; }

        [Required]
        public bool IsContaminated { get; set; }

        [Required]
        public double Latitude { get; set; }

        [Required]
        public double Longitude { get; set; }
    }
}
