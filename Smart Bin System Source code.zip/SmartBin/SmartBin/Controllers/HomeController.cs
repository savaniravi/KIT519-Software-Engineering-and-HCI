using Microsoft.AspNetCore.Mvc;
using SmartBin.Filters;
using SmartBin.Models;
using System.Diagnostics;

namespace SmartBin.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // New action methods for the pages
        public IActionResult About()
        {
            return View();
        }

        public IActionResult SuccessStory()
        {
            var successStories = _context.SuccessStories.OrderByDescending(s => s.PostedOn).ToList();
            return View(successStories);
        }

        [AuthFilter]
        public IActionResult DataAnalytics()
        {
            var reports = _context.Reports.ToList();
            return View(reports);
        }

        [AuthFilter]
        public IActionResult BinMonitoring()
        {
            var bins = _context.Bins.ToList();
            return View(bins);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
